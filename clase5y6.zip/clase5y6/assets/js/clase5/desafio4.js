function sumarProductos(precioUnitario,cantidadDeseada){
    return precioUnitario * cantidadDeseada
}

let pre = 500
let cant = prompt('Ingrese la cantidad que quiere comprar')

alert(sumarProductos(pre,cant))
//console.log(sumarProductos(pre,cant))