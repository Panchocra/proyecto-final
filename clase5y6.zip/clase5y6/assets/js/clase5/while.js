let contador = 1

while(contador <= 5){
    console.log('hola')
    contador = contador + 2 
}

