


let nombres = [UsuarioElige]


let UsuarioElige = prompt('Ingresa el dato que quieras')
//nombres.push(UsuarioElige)


console.log(nombres)