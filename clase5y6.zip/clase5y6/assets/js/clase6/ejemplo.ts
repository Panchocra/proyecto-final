interface Usuarios{
    nombre:string;
    aprellido:string;
    edad:number;
    barrio:string;
}